/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import config.Koneksi;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Tiket;

/**
 *
 * @author EBY
 */
public class FormTiket extends javax.swing.JFrame {
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FormTiket.class.getName());
    Connection con;
    DefaultTableModel modelTabel;

    public FormTiket() {
        initComponents();
        load_table();     
        load_combobox();  
    }

    private void load_table() {
        Object[] baris = {"ID Tiket", "Nama Customer", "Nomor Kursi", "Film & Jadwal", "Total Bayar"};
        modelTabel = new DefaultTableModel(null, baris);
        tblTiket.setModel(modelTabel);
        
        String sql = "SELECT t.id_tiket, t.nama_customer, t.nomor_kursi, t.total_bayar, f.judul, j.jam_tayang "
                   + "FROM tiket t JOIN jadwal j ON t.id_jadwal = j.id_jadwal JOIN film f ON j.id_film = f.id_film";
        try {
            con = Koneksi.getKoneksi();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                String[] data = {
                    rs.getString("id_tiket"),
                    rs.getString("nama_customer"),
                    rs.getString("nomor_kursi"),
                    rs.getString("judul") + " (" + rs.getString("jam_tayang") + ")",
                    "Rp " + rs.getString("total_bayar")
                };
                modelTabel.addRow(data);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Gagal memuat tabel: " + e.getMessage());
        }
    }

    private void load_combobox() {
        cbJadwal.removeAllItems();
        cbJadwal.addItem("-- Pilih Jadwal Film --");
        String sql = "SELECT j.id_jadwal, f.judul, j.jam_tayang FROM jadwal j JOIN film f ON j.id_film = f.id_film";
        try {
            con = Koneksi.getKoneksi();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                cbJadwal.addItem(rs.getString("id_jadwal") + ". " + rs.getString("judul") + " (" + rs.getString("jam_tayang") + ")");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Gagal memuat jadwal: " + e.getMessage());
        }
    }

    private void updatePreview() {
        if (cbJadwal == null || cbJadwal.getSelectedItem() == null || cbJadwal.getSelectedIndex() <= 0) {
            if (lblDetailStudio != null) lblDetailStudio.setText("Studio: -");
            if (lblTotalPreview != null) lblTotalPreview.setText("Total: Rp 0");
            return; 
        }

        try {
            String selectedItem = cbJadwal.getSelectedItem().toString();
            int idJadwal = Integer.parseInt(selectedItem.split("\\.")[0]);

            String sql = "SELECT j.harga_dasar, s.nama_studio, s.tipe_studio FROM jadwal j "
                       + "JOIN studio s ON j.id_studio = s.id_studio WHERE j.id_jadwal = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idJadwal);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                double hargaDasar = rs.getDouble("harga_dasar");
                String namaStudio = rs.getString("nama_studio");
                String tipeStudio = rs.getString("tipe_studio");
                
                lblDetailStudio.setText("Studio: " + namaStudio + " (" + tipeStudio + ")");
                
                // Penerapan Polimorfisme OOP
                model.Studio objekStudio;
                if (tipeStudio.equalsIgnoreCase("IMAX")) {
                    objekStudio = new model.StudioIMAX(namaStudio, hargaDasar);
                } else if (tipeStudio.equalsIgnoreCase("Premiere")) {
                    objekStudio = new model.StudioPremiere(namaStudio, hargaDasar);
                } else {
                    objekStudio = new model.StudioReguler(namaStudio, hargaDasar);
                }
                
                double totalHarga = objekStudio.hitungHargaTiket();
                lblTotalPreview.setText("Total: Rp " + totalHarga);
            }
        } catch (SQLException e) {
            System.out.println("Error preview: " + e.getMessage());
        }
    }

    private void clear_form() {
        txtNama.setText("");
        txtKursi.setText("");
        cbJadwal.setSelectedIndex(0);
        lblDetailStudio.setText("Studio: -");
        lblTotalPreview.setText("Total: Rp 0");
        btnSimpan.setEnabled(true);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtNama = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtKursi = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        cbJadwal = new javax.swing.JComboBox<>();
        lblDetailStudio = new javax.swing.JLabel();
        lblTotalPreview = new javax.swing.JLabel();
        btnSimpan = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblTiket = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel1.setText("APLIKASI BOOKING TIKET BIOSKOP");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setText("Nama Customer");

        txtNama.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        txtNama.addActionListener(this::txtNamaActionPerformed);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel4.setText("Nomor Kursi");

        txtKursi.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setText("Pilih Jadwal Film");

        cbJadwal.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        cbJadwal.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbJadwal.addActionListener(this::cbJadwalActionPerformed);

        lblDetailStudio.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblDetailStudio.setText("Studio: -");

        lblTotalPreview.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblTotalPreview.setText("Total: Rp 0");

        btnSimpan.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnSimpan.setText("Pesan Tiket");
        btnSimpan.addActionListener(this::btnSimpanActionPerformed);

        btnUpdate.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnUpdate.setText("Ubah Kursi");
        btnUpdate.addActionListener(this::btnUpdateActionPerformed);

        btnDelete.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnDelete.setText("Batalkan Tiket");
        btnDelete.addActionListener(this::btnDeleteActionPerformed);

        btnClear.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnClear.setText("Clear Form");
        btnClear.addActionListener(this::btnClearActionPerformed);

        tblTiket.setFont(new java.awt.Font("Times New Roman", 2, 12)); // NOI18N
        tblTiket.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblTiket.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblTiketMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblTiket);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 572, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSimpan)
                                .addGap(18, 18, 18)
                                .addComponent(btnUpdate)
                                .addGap(120, 120, 120)
                                .addComponent(btnDelete)
                                .addGap(18, 18, 18)
                                .addComponent(btnClear))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(73, 73, 73)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3))
                        .addGap(53, 53, 53)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNama)
                            .addComponent(txtKursi)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblTotalPreview)
                                    .addComponent(lblDetailStudio))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(cbJadwal, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(49, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(190, 190, 190))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jLabel1)
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtNama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtKursi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(cbJadwal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(lblDetailStudio)
                .addGap(18, 18, 18)
                .addComponent(lblTotalPreview)
                .addGap(48, 48, 48)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSimpan)
                    .addComponent(btnUpdate)
                    .addComponent(btnDelete)
                    .addComponent(btnClear))
                .addGap(64, 64, 64)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(168, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNamaActionPerformed

    private void btnSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpanActionPerformed
        if (txtNama.getText().isEmpty() || txtKursi.getText().isEmpty() || cbJadwal.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(this, "Semua data wajib diisi!");
            return;
        }

        try {
            String selectedItem = cbJadwal.getSelectedItem().toString();
            int idJadwal = Integer.parseInt(selectedItem.split("\\.")[0]);
            String nama = txtNama.getText();
            String kursi = txtKursi.getText();
            
            String bersihHarga = lblTotalPreview.getText().replace("Total: Rp ", "");
            double totalBayar = Double.parseDouble(bersihHarga);

            Tiket tiketBaru = new Tiket(idJadwal, nama, kursi, totalBayar);

            String sqlInsert = "INSERT INTO tiket (id_jadwal, nama_customer, nomor_kursi, total_bayar) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sqlInsert);
            ps.setInt(1, tiketBaru.getIdJadwal());
            ps.setString(2, tiketBaru.getNamaCustomer());
            ps.setString(3, tiketBaru.getNomorKursi());
            ps.setDouble(4, tiketBaru.getTotalBayar());
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(this, "Tiket Berhasil Dipesan!");
            load_table();
            clear_form();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Gagal menyimpan: " + e.getMessage());
        }
    }//GEN-LAST:event_btnSimpanActionPerformed

    private void cbJadwalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbJadwalActionPerformed
        updatePreview();
    }//GEN-LAST:event_cbJadwalActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        int barisTerpilih = tblTiket.getSelectedRow();
        if (barisTerpilih == -1) {
            JOptionPane.showMessageDialog(this, "Pilih data di tabel dulu!");
            return;
        }
        
        try {
            String idTiket = modelTabel.getValueAt(barisTerpilih, 0).toString();
            String kursiBaru = txtKursi.getText();
            
            String sql = "UPDATE tiket SET nomor_kursi = ? WHERE id_tiket = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, kursiBaru);
            ps.setString(2, idTiket);
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(this, "Nomor Kursi Berhasil Diperbarui!");
            load_table();
            clear_form();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Gagal mengupdate: " + e.getMessage());
        }
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        int barisTerpilih = tblTiket.getSelectedRow();
        if (barisTerpilih == -1) {
            JOptionPane.showMessageDialog(this, "Pilih data di tabel dulu!");
            return;
        }
        
        String idTiket = modelTabel.getValueAt(barisTerpilih, 0).toString();
        int konfirmasi = JOptionPane.showConfirmDialog(this, "Batalkan tiket ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
        
        if (konfirmasi == JOptionPane.YES_OPTION) {
            try {
                String sql = "DELETE FROM tiket WHERE id_tiket = ?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, idTiket);
                ps.executeUpdate();
                
                JOptionPane.showMessageDialog(this, "Tiket berhasil dibatalkan!");
                load_table();
                clear_form();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Gagal menghapus: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        clear_form();
    }//GEN-LAST:event_btnClearActionPerformed

    private void tblTiketMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblTiketMouseClicked
        int barisTerpilih = tblTiket.getSelectedRow();
        if (barisTerpilih != -1) {
            txtNama.setText(modelTabel.getValueAt(barisTerpilih, 1).toString());
            txtKursi.setText(modelTabel.getValueAt(barisTerpilih, 2).toString());
            btnSimpan.setEnabled(false); 
        }
    }//GEN-LAST:event_tblTiketMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new FormTiket().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnSimpan;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JComboBox<String> cbJadwal;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblDetailStudio;
    private javax.swing.JLabel lblTotalPreview;
    private javax.swing.JTable tblTiket;
    private javax.swing.JTextField txtKursi;
    private javax.swing.JTextField txtNama;
    // End of variables declaration//GEN-END:variables
}
