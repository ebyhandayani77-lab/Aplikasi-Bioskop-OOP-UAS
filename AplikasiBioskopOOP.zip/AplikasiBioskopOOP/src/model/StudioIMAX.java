/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author EBY
 */
public class StudioIMAX extends Studio {
    public StudioIMAX(String namaStudio, double hargaDasar) {
        super(namaStudio, hargaDasar);
    }

    @Override
    public double hitungHargaTiket() {
        return super.hitungHargaTiket() + 15000; // Biaya tambahan IMAX Rp 15.000
    }
}