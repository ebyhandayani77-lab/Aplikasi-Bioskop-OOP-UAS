/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author EBY
 */
public class StudioPremiere extends Studio {
    public StudioPremiere(String namaStudio, double hargaDasar) {
        super(namaStudio, hargaDasar);
    }

    @Override
    public double hitungHargaTiket() {
        return super.hitungHargaTiket() + 30000; // Biaya tambahan Premiere Rp 30.000
    }
}