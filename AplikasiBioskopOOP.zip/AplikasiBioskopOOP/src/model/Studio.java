/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author EBY
 */
public class Studio {
    protected String namaStudio;
    protected double hargaDasar;

    public Studio(String namaStudio, double hargaDasar) {
        this.namaStudio = namaStudio;
        this.hargaDasar = hargaDasar;
    }

    // Metode yang akan di-override oleh sub-class (Polymorphism)
    public double hitungHargaTiket() {
        return this.hargaDasar;
    }
}
