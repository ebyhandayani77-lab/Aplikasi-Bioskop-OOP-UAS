/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author EBY
 */
public class StudioReguler extends Studio {
    public StudioReguler(String namaStudio, double hargaDasar) {
        super(namaStudio, hargaDasar);
    }

    @Override
    public double hitungHargaTiket() {
        return super.hitungHargaTiket(); // Reguler tidak ada biaya tambahan
    }
}
