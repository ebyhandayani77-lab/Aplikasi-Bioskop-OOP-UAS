/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author EBY
 */
public class Tiket {
    private int idJadwal;
    private String namaCustomer;
    private String nomorKursi;
    private double totalBayar;

    // Constructor
    public Tiket(int idJadwal, String namaCustomer, String nomorKursi, double totalBayar) {
        this.idJadwal = idJadwal;
        this.namaCustomer = namaCustomer;
        this.nomorKursi = nomorKursi;
        this.totalBayar = totalBayar;
    }

    // Getter dan Setter (Encapsulation)
    public int getIdJadwal() { return idJadwal; }
    public void setIdJadwal(int idJadwal) { this.idJadwal = idJadwal; }

    public String getNamaCustomer() { return namaCustomer; }
    public void setNamaCustomer(String namaCustomer) { this.namaCustomer = namaCustomer; }

    public String getNomorKursi() { return nomorKursi; }
    public void setNomorKursi(String nomorKursi) { this.nomorKursi = nomorKursi; }

    public double getTotalBayar() { return totalBayar; }
    public void setTotalBayar(double totalBayar) { this.totalBayar = totalBayar; }
}